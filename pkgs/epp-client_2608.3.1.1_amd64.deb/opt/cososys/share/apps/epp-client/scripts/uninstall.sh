#!/usr/bin/env sh
#
# unistall.sh
#
# Created on: 29 Jun 2020
# Target: all Linux distros machines
#
# Copyright (c) 2020
#      CoSoSys SRL All rights reserved.
#
# Endpoint Protector offers Data Loss Prevention for Windows, Mac and Linux, as well as
# Mobile Device Management for Android and iOS.
#

if [ "$(whoami)" != "root" ]; then
    exit
fi

_epp_client_daemon_pid="$(pgrep -f epp-client-daemon)"
if [ -n "${_epp_client_daemon_pid}" ]; then
    kill -s USR2 "${_epp_client_daemon_pid}"
    for _t in $(seq 1 5); do
        sleep 1
    done
fi

pkill epp-client

if command -v dpkg; then
	dpkg --purge epp-client
fi

if command -v rpm; then
	rpm -e epp-client
fi
